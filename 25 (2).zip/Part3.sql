--Part 1:
-- Number 1
SELECT      [League] = T.League,
	        [Sport Type] = L.[Sport Type],
	        [Num of orders] = COUNT(DISTINCT O.[Order ID]),
	        [Total sold products] = SUM(c.Quantity),
            [Total income] = ROUND(SUM(P.Price*C.Quantity*(1 - C.Discount)*(1 - O.Coupon)),2)
FROM        PRODUCTS AS P JOIN TEAMS AS T ON P.Team = T.Team
            JOIN [CONTAINS] AS C ON p.[Serial Number] = C.[Serial Number]
            JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
            JOIN LEAGUES AS L ON T.League = L.League
WHERE       Year(O.[Order DT]) = 2023
GROUP BY    T.League, L.[Sport Type]
HAVING      COUNT(DISTINCT O.[Order ID]) >= 20
ORDER BY    [Total income] DESC


-- Number 2
SELECT  TOP 30 
        P.[Serial Number], P.Type, P.Price, TotalSold = SUM (C.Quantity)
FROM    PRODUCTS AS P JOIN [CONTAINS] AS C ON P.[Serial Number] = C.[Serial Number] 
        JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
WHERE   DATEDIFF (dd, O.[Order DT], GETDATE()) <= 365
GROUP BY P.[Serial Number], P.Type, P.Price
ORDER BY TotalSold, P.Price


-- Number 3 
SELECT      TOP 5 
            Country = C.[Address- Country], 
            [Total Orders Per Country] = COUNT(O.[Order ID]),
            [Total Orders],
            Proportion = ROUND(CAST(COUNT(O.[Order ID])AS float) 
                                / CAST([Total Orders] AS float),2)
FROM        CUSTOMERS AS C JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
            JOIN ORDERS AS O ON O.[Card Number] = CC.[Card Number]
            CROSS JOIN (SELECT [Total Orders] = COUNT(*) FROM ORDERS) AS O1
GROUP BY    C.[Address- Country], [Total Orders]
ORDER BY    Proportion DESC


-- Number 4 
SELECT	
        SoldBySearch = (SELECT COUNT (*)
                        FROM    FINDS AS F 
                                JOIN [CONTAINS] AS C ON F.[Serial Number] = C.[Serial Number] 
                                JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
                        WHERE   CONVERT(DATE, O.[Order DT]) = CONVERT(DATE, F.[Search DT]) 
                                AND O.[Order ID] = C.[Order ID] 
                                AND C.[Serial Number] = F.[Serial Number]),
        TotalOrders = (SELECT COUNT (*) FROM [CONTAINS]), 
        Proportion = CAST((SELECT COUNT(*)
                        FROM    FINDS AS F 
                                JOIN [CONTAINS] AS C ON F.[Serial Number] = C.[Serial Number] 
                                JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
                        WHERE CONVERT(DATE, O.[Order DT]) = CONVERT(DATE, F.[Search DT]) 
                                AND O.[Order ID] = C.[Order ID] 
                                AND C.[Serial Number] = F.[Serial Number]) AS DECIMAL)
                                    / (SELECT COUNT(*) FROM [CONTAINS])


-- Number 5
-- Add Active column to Account Users Table
ALTER TABLE [ACCOUNTS USERS] ADD Active int;

-- Update Active Column to 1 if active in the last 6 months
UPDATE [ACCOUNTS USERS]
SET Active = CASE
    WHEN (
        SELECT COUNT(DISTINCT o.[Order ID])
        FROM [ACCOUNTS USERS] AS a
        JOIN CUSTOMERS AS c ON a.ID = c.ID
        JOIN [CREDIT CARDS] AS cc ON cc.[Customer ID] = c.ID
        JOIN ORDERS AS o ON o.[Card Number] = cc.[Card Number]
        WHERE a.ID = [ACCOUNTS USERS].ID 
              AND DATEADD(Month, -6, getdate()) < O.[Order DT]
    ) > 5 THEN 1
    ELSE 0
END

SELECT ID, [Join Date], Active
FROM [ACCOUNTS USERS]
ORDER BY Active DESC


-- Number 6
SELECT  PP.[Serial Number],
        [Ordered Not By Search] = COUNT (PP.[Order ID])
FROM    (SELECT C.[Order ID], C.[Serial Number]
        FROM [CONTAINS] AS C
        EXCEPT
        SELECT O.[Order ID], P.[Serial Number]
        FROM PRODUCTS AS P
        JOIN [CONTAINS] AS C ON C.[Serial Number] = P.[Serial Number] 
        JOIN FINDS AS F ON F.[Serial Number] = C.[Serial Number] 
        JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
        JOIN SEARCHES AS S ON F.[Search DT] = S.[Search DT]
        WHERE CONVERT(DATE, O.[Order DT]) = CONVERT(DATE, F.[Search DT]) 
        AND O.[Order ID] = C.[Order ID] 
        AND C.[Serial Number] = F.[Serial Number]
        AND CONVERT(VARCHAR(100), P.[Type]) = CONVERT(VARCHAR(100), S.[Search Text])) AS PP
GROUP BY PP.[Serial Number]
ORDER BY [Ordered Not By Search] DESC



--part 2:
-- Number 7
-- DROP VIEW CustomerToProductView
CREATE VIEW CustomerToProductView AS
SELECT 
		O.[Order ID],[Order Date] = convert (Date, O.[Order DT]), 
        [Customer ID] = C.ID, [Full Name] = C.[Name- First] + ' ' + C.[Name- Last],
		[Num Of Products] = SUM (CON.Quantity), 
		[Price Before Discounts] = SUM (P.Price * CON.Quantity), 
		Coupon = CASE WHEN O.Coupon > 0 THEN 'YES' ELSE 'NO' END,
		[Total Discounts] = ROUND (SUM (P.Price * CON.Quantity) 
                            - ROUND(SUM(P.Price * CON.Quantity * (1-CON.Discount)) * (1-O.Coupon),2), 2),
		[Total Paid Amount] = ROUND (SUM(P.Price * CON.Quantity * (1-CON.Discount)) * (1-O.Coupon),2)
FROM	CUSTOMERS AS C JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
        JOIN ORDERS AS O ON CC.[Card Number] = O.[Card Number] 
		JOIN [CONTAINS] AS CON ON O.[Order ID] = CON.[Order ID] 
        JOIN PRODUCTS AS P ON CON.[Serial Number] = P.[Serial Number]
GROUP BY O.[Order ID], C.ID, C.[Name- First], C.[Name- Last], O.Coupon, O.[Order DT]

SELECT *
FROM CustomerToProductView
ORDER BY [Total Paid Amount] DESC


-- Number 8 
-- DROP FUNCTION Most_popular_products
CREATE FUNCTION Most_popular_products (@INPUT_COUNTRY VARCHAR(30))
RETURNS @ResultTable TABLE (
        [Product] VARCHAR(30),
	    [Style] VARCHAR(20),
	    [Type] VARCHAR(20),
        [Country] VARCHAR(30),
        [Num of sold products] INT
)
AS
BEGIN
        INSERT INTO @ResultTable
        SELECT TOP 10
                [Product]=p.[Serial Number],
		        [Style]=p.[Style], 
		        [Type]=P.[Type],
                [Country]=cust.[Address- Country],
                [Num of sold products]= COUNT(c.Discount)
        FROM    PRODUCTS AS p
                JOIN [CONTAINS] AS c ON p.[Serial Number] = c.[Serial Number]
                JOIN FINDS AS f ON p.[Serial Number] = f.[Serial Number]
                JOIN SEARCHES AS s ON f.[Search DT] = s.[Search DT]
                JOIN CUSTOMERS AS cust ON s.[Customer ID] = cust.ID
        WHERE cust.[Address- Country] = @INPUT_COUNTRY
        GROUP BY p.[Serial Number], cust.[Address- Country], p.[Style], p.[Type]
	    Order by [Num of sold products] DESC
        RETURN
END

SELECT *
FROM [bgu-users\zilbemay].Most_popular_products('USA')


-- Number 9 
-- DROP FUNCTION ProductPurchaseCountSince
CREATE FUNCTION ProductPurchaseCountSince (@ProductID Int, @StartDate Date)
RETURNS Int
AS
BEGIN 
        DECLARE @PurchaseCount Int

        SELECT @PurchaseCount = SUM(C.Quantity)
        FROM [CONTAINS] AS C JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
        WHERE C.[Serial Number] = @ProductID AND O.[Order DT] >= @StartDate

        RETURN @PurchaseCount
END

SELECT  [Serial Number], Type, Price, 
        [Last 6 Months Purchased] = [bgu-users\zilbemay].ProductPurchaseCountSince ([Serial Number],DATEADD (MONTH, -6,GETDATE())),
        [Revenue Without Discounts] = Price *
                                     [bgu-users\zilbemay].ProductPurchaseCountSince ([Serial Number],DATEADD(MONTH, -6,GETDATE()))
FROM PRODUCTS
ORDER BY [Last 6 Months Purchased] DESC, Price DESC


-- Number 10 
-- Add new column to Customers table
ALTER TABLE CUSTOMERS ADD [Total Num Of Orders] int

-- Fill the Column with the current DATA 
UPDATE  CUSTOMERS
SET     [Total Num Of Orders] = 
        (SELECT COUNT (DISTINCT O.[Order ID])
        FROM    CUSTOMERS AS C 
        JOIN    [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
        JOIN    ORDERS AS O ON O.[Card Number] = CC.[Card Number]
        WHERE   C.ID = CUSTOMERS.ID
        GROUP BY O.[Card Number])

-- TRIGGER:
-- DROP TRIGGER UpdateTotalNumOfOrders
GO

--Create Trigger
CREATE TRIGGER UpdateTotalNumOfOrders
ON ORDERS 
FOR INSERT, DELETE
AS 
UPDATE  CUSTOMERS
SET     [Total Num Of Orders] =
        (SELECT COUNT (O.[Order ID])
        FROM    CUSTOMERS AS C 
        JOIN    [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
        JOIN    ORDERS AS O ON O.[Card Number] = CC.[Card Number]
        WHERE   CUSTOMERS.ID = C.ID )
WHERE   [ID] IN (
        SELECT DISTINCT [ID] FROM INSERTED
        UNION
        SELECT DISTINCT [ID] FROM DELETED) 

-- New Customer added to CUSTOMERS only When he did an order !

INSERT INTO ORDERS VALUES (501, 0.0, 2023-06-11, 3877490979721010)
INSERT INTO [CONTAINS] VALUES (96, 501, 1, 0.0)
INSERT INTO ORDERS VALUES (502, 0.0, 2023-06-12, 3877490979721010)
INSERT INTO [CONTAINS] VALUES (21, 502, 1, 0.1)

DELETE FROM [CONTAINS] WHERE [Order ID] = 501
DELETE FROM ORDERS WHERE [Order ID] = 501
DELETE FROM [CONTAINS] WHERE [Order ID] = 502
DELETE FROM ORDERS WHERE [Order ID] = 502

SELECT *
FROM CUSTOMERS


-- Number 11
-- DROP PROCEDURE Update_Price
CREATE PROCEDURE Update_Price
                 @New_Discount REAL,
                 @Sport_Type VARCHAR(30)
AS 
BEGIN
        IF OBJECT_ID('UpdatePrice') IS NOT NULL
            DROP TABLE UpdatePrice;

        CREATE TABLE UpdatePrice (
                    [Serial Number] INT NOT NULL,
                    [Sport Type] VARCHAR(30) NOT NULL,
                    [Type] VARCHAR(30),
		            [Price] MONEY,
                    [Updated Discount] REAL NOT NULL,
                    [New Price] MONEY,
        PRIMARY KEY ([Serial Number])
    );

    INSERT INTO UpdatePrice ([Serial Number],[Sport Type],[Type],
                                [Price],[Updated Discount],[New Price])

    SELECT  P.[Serial Number], L.[Sport Type], P.[Type], [Price] = P.Price, 
            [Updated Discount] = CASE WHEN L.[Sport Type] = 
                                 @Sport_Type THEN @New_Discount ELSE 0 END, 
            [New Price] = P.Price*(1 - CASE WHEN L.[Sport Type] =
                         @Sport_Type THEN @New_Discount ELSE 0 END)
    FROM    [CONTAINS] AS C JOIN PRODUCTS AS P ON C.[Serial Number] = P.[Serial Number]
            JOIN TEAMS AS T ON P.Team = T.Team
            JOIN LEAGUES AS L ON T.League = L.League
    GROUP BY P.[Serial Number], L.[Sport Type], P.[Type], P.Price
END

--Run the Procedure
DECLARE @Sport_Type VARCHAR(30)='Soccer'
DECLARE @New_Discount REAL = 0.2

EXEC Update_Price  @New_Discount , @Sport_Type
SELECT *
FROM UpdatePrice;



-- PART 3:
-- DROP VIEW Account_User_Report_View
CREATE VIEW Account_User_Report_View AS
SELECT 
		O.[Order ID],[Order Date] = convert (Date, O.[Order DT]), 
        [Account User ID] = AU.ID, 
        [Full Name] = C.[Name- First] + ' ' + C.[Name- Last], 
        P.[Serial Number], P.Type, P.Team, L.League, L.[Sport Type],
		[Num Of Products] = SUM (CON.Quantity), 
        [Product Price] = P.Price,
		[Price Before Discounts] = SUM (P.Price * CON.Quantity), 
		Coupon = CASE WHEN O.Coupon > 0 THEN 'YES' ELSE 'NO' END,
		[Total Discounts] = ROUND (SUM (P.Price * CON.Quantity) - 
                            ROUND(SUM(P.Price*CON.Quantity*(1-CON.Discount))*(1-O.Coupon),2),2),
		[Total Paid Amount] = ROUND(SUM(P.Price*CON.Quantity*(1-CON.Discount))*(1-O.Coupon),2)
FROM	[ACCOUNTS USERS] AS AU JOIN CUSTOMERS AS C ON AU.ID = C.ID 
        JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
        JOIN ORDERS AS O ON CC.[Card Number] = O.[Card Number] 
		JOIN [CONTAINS] AS CON ON O.[Order ID] = CON.[Order ID] 
        JOIN PRODUCTS AS P ON CON.[Serial Number] = P.[Serial Number]
		JOIN TEAMS AS T ON T.Team = P.Team JOIN LEAGUES AS L ON L.League = T.League
GROUP BY O.[Order ID], AU.ID, C.[Name- First], C.[Name- Last], O.Coupon, O.[Order DT], 
        P.[Serial Number], P.Type, P.Price, P.Team, L.League, L.[Sport Type]


-- Drop VIEW DashBoard
CREATE VIEW DashBoard AS
SELECT 
		O.[Order ID],[Order Date] = convert (Date, O.[Order DT]), 
        [Customer ID] = C.ID, 
        [Full Name] = C.[Name- First] + ' ' + C.[Name- Last],
		C.[Address- City], C.[Address- Country], P.[Serial Number], 
        P.[Gender/Age],P.Type, P.Team, L.League, L.[Sport Type],
		[Num Of Products] = SUM (CON.Quantity),
		[Price Before Discounts] = SUM (P.Price * CON.Quantity), 
		[Total Discounts] = ROUND (SUM (P.Price * CON.Quantity) - 
                            ROUND(SUM(P.Price*CON.Quantity*(1-CON.Discount))*(1 - O.Coupon),2), 2),
		[Total Paid Amount] = ROUND (SUM(P.Price*CON.Quantity*(1-CON.Discount))*(1-O.Coupon),2)
FROM	CUSTOMERS AS C JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID] 
        JOIN ORDERS AS O ON CC.[Card Number] = O.[Card Number] 
		JOIN [CONTAINS] AS CON ON O.[Order ID] = CON.[Order ID] 
        JOIN PRODUCTS AS P ON CON.[Serial Number] = P.[Serial Number]
		JOIN TEAMS AS T ON T.Team = P.Team 
        JOIN LEAGUES AS L ON L.League = T.League
GROUP BY    O.[Order ID], C.ID, C.[Name- First], C.[Name- Last],  
            O.[Order DT], P.[Serial Number],O.Coupon ,P.Type, P.Price, 
            P.Team, L.League, L.[Sport Type], C.[Address- City], 
            C.[Address- Country], P.[Gender/Age]



-- Part 4: 
-- WINDOW FANCTION number 1
SELECT  P.[Serial Number], P.Type, P.Price, 
        [Total Amount] = ROUND(Sum (P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2),
        [Rank By Type] = RANK () OVER (Partition by P.type 
                                        ORDER BY SUM (P.Price*C.Quantity*(1-C.Discount)*(1-O.Coupon)) DESC),
        [Classification Group By Type] = NTILE (5) OVER (Partition By P.type 
                                                        ORDER BY SUM (P.Price*C.Quantity*(1-C.Discount)*(1-O.Coupon)) DESC)
FROM    PRODUCTS AS P JOIN [CONTAINS] AS C ON P.[Serial Number] = C.[Serial Number] 
        JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
GROUP BY P.[Serial Number], P.Type, P.Price


-- WINDOW FANCTION number 2
SELECT  L.[Sport Type], [Month] = MONTH (O.[Order DT]), 
        [Num Of Sold Products] = SUM(C.Quantity),
        [Total Revenue] = ROUND(SUM(P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2),
        [Difference In Income] = ROUND(SUM(P.Price*C.Quantity*(1-C.Discount)*(1-O.Coupon)),2) -
        LAG(ROUND(Sum (P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2)) 
            OVER (Partition By L.[Sport Type] 
            ORDER BY MONTH (O.[Order DT])),
        [Gap From Best Month] = FIRST_VALUE(ROUND(SUM(P.Price*C.Quantity*(1-C.Discount)*(1-O.Coupon)),2)) 
            OVER (Partition By L.[Sport Type] 
            ORDER BY ROUND(Sum (P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2) DESC)- 
        ROUND(Sum (P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2),
        [Revenue Rank] = Rank () OVER (Partition by L.[Sport Type] 
            ORDER BY ROUND(Sum (P.Price * C.Quantity * (1-C.Discount) * (1-O.Coupon)),2) DESC)
FROM    LEAGUES AS L JOIN TEAMS AS T ON L.League = T.League 
        JOIN PRODUCTS AS P ON P.Team = T.Team 
        JOIN [CONTAINS] AS C ON P.[Serial Number] = C.[Serial Number] 
        JOIN ORDERS AS O ON C.[Order ID] = O.[Order ID]
WHERE Year(O.[Order DT]) = 2023
GROUP BY L.[Sport Type], MONTH (O.[Order DT])
ORDER BY L.[Sport Type], [Month]



--Procedure that combines 2 functions and a trigger
--add a Column to Products table
ALTER TABLE PRODUCTS
ADD IsBestSeller Int

--SELECT *
--FROM PRODUCTS

--DROP FUNCTION isSoldAboveAvg
CREATE FUNCTION isSoldAboveAvg (@Product Int)
RETURNS Int
AS
BEGIN
     DECLARE @AboveAVG Int
	 SET @AboveAVG  = (CASE WHEN (SELECT SUM(C.Quantity)
								  FROM [CONTAINS] AS C
                                  WHERE @Product = C.[Serial Number] ) >  (SELECT AVG (S.SUM)
																           FROM  (SELECT SUM = (SUM(C.Quantity))
																				  FROM [CONTAINS] AS C
																				  GROUP BY C.[Serial Number]) AS S)
																				  THEN 1 ELSE 0 END)																																	
	 RETURN @AboveAVG 
END



--  isSoldAboveAvg 
DECLARE @AVG FLOAT

SELECT @AVG = AVG(SUM)
FROM (
    SELECT SUM = SUM(C.Quantity) 
    FROM [CONTAINS] AS C
    GROUP BY C.[Serial Number]
) AS S

SELECT C.[Serial Number], [AVG] = @AVG, [Sum] = SUM(C.Quantity), isSoldAboveAvg = [bgu-users\zilbemay].isSoldAboveAvg(C.[Serial Number])
FROM [CONTAINS] AS C
JOIN PRODUCTS AS P ON P.[Serial Number] = C.[Serial Number]
GROUP BY C.[Serial Number]




--DROP FUNCTION isAboveAvgPrice
CREATE FUNCTION isAboveAvgPrice (@Product Int)
RETURNS Int
AS
BEGIN
     DECLARE @AboveAVG Int
	 SET @AboveAVG  = (CASE WHEN (SELECT SUM(P.Price * C.Quantity * (1-C.Discount))
								  FROM [CONTAINS] AS C join PRODUCTS AS P ON P.[Serial Number] = C.[Serial Number]
                                  WHERE @Product = C.[Serial Number] ) >  (SELECT AVG (S.SUM)
																           FROM  (SELECT SUM = SUM (P.Price * C.Quantity * (1-C.Discount))
																				  FROM [CONTAINS] AS C join PRODUCTS AS P ON P.[Serial Number] = C.[Serial Number]
																				  GROUP BY C.[Serial Number]) AS S) THEN 1 ELSE 0 END)																		
	 RETURN @AboveAVG
END


-- isAboveAvgPrice 
DECLARE @AVG FLOAT

SELECT @AVG = AVG (S.SUM)
FROM (
  SELECT SUM = SUM(P.Price * C.Quantity * (1 - C.Discount))
  FROM [CONTAINS] AS C
  JOIN PRODUCTS AS P ON P.[Serial Number] = C.[Serial Number]
  GROUP BY C.[Serial Number]
) AS S

SELECT C.[Serial Number], [AVG] = @AVG, [Sum] = SUM(P.Price * C.Quantity * (1 - C.Discount)), AboveAVG = [bgu-users\zilbemay].isAboveAvgPrice(C.[Serial Number]) 
FROM [CONTAINS] AS C
JOIN PRODUCTS AS P ON P.[Serial Number] = C.[Serial Number]
GROUP BY C.[Serial Number]


--DROP TRIGGER UpdatePriceToBestSellers   
CREATE	TRIGGER UpdatePriceToBestSellers
ON PRODUCTS FOR INSERT, UPDATE
AS
UPDATE	PRODUCTS  
SET PRODUCTS.Price = ISNULL((SELECT 1.1 * P.Price  
							 FROM   PRODUCTS as P
							 WHERE  P.IsBestSeller = 1 
							 AND	P.[Serial Number] = PRODUCTS.[Serial Number]), PRODUCTS.Price)
WHERE [Serial Number] IN (
           SELECT [Serial Number] FROM inserted) 

--select *
--from PRODUCTS



--PROCEDURE
--DROP PROCEDURE UpdateBestSellers 
CREATE PROCEDURE UpdateBestSellers 
AS
BEGIN
    UPDATE PRODUCTS
    SET IsBestSeller = 1
    WHERE [Serial Number] IN (
        SELECT P.[Serial Number]
        FROM PRODUCTS AS P
        WHERE [bgu-users\zilbemay].isSoldAboveAvg(P.[Serial Number]) = 1
        AND [bgu-users\zilbemay].isAboveAvgPrice(P.[Serial Number]) = 1
    )

    UPDATE PRODUCTS
    SET IsBestSeller = 0
    WHERE [Serial Number] IN (
        SELECT P.[Serial Number]	
        FROM PRODUCTS AS P
        WHERE [bgu-users\zilbemay].isSoldAboveAvg(P.[Serial Number]) = 0
        OR [bgu-users\zilbemay].isAboveAvgPrice(P.[Serial Number]) = 0
    )
END

--Procedure Run
EXEC UpdateBestSellers 
SELECT *
FROM PRODUCTS 
   


--With function
-- FUNCTION
-- Drop FUNCTION [bgu-users\zilbemay].loyaltyLevelPlusPoints
GO
CREATE FUNCTION [bgu-users\zilbemay].loyaltyLevelPlusPoints (@TotalPayment REAL)
RETURNS @loyaltyLevelPoints TABLE(
        [Loyalty Club] VARCHAR(10),
        [Club benefit] REAL)
AS
BEGIN
    INSERT INTO @loyaltyLevelPoints ([Loyalty Club],[Club benefit])
    SELECT [Loyalty Club] = CASE 
                            WHEN @TotalPayment >= 0.0 AND @TotalPayment < 500.00 THEN 'REGULAR'
                            WHEN @TotalPayment >= 500.0 AND @TotalPayment < 1500.0 THEN 'SILVER'
                            WHEN @TotalPayment >= 1500.0 AND @TotalPayment < 5000.0 THEN 'GOLD'
                            ELSE 'DIAMOND' 
                            END,
            [Club benefit] = CASE 
                            WHEN @TotalPayment >= 0.0 AND @TotalPayment < 500.00 THEN 0 * @TotalPayment / 100
                            WHEN @TotalPayment >= 500.0 AND @TotalPayment < 1500.0 THEN 5 * @TotalPayment / 100
                            WHEN @TotalPayment >= 1500.0 AND @TotalPayment < 5000.0 THEN 10 * @TotalPayment / 100
                            ELSE 15 * @TotalPayment / 100
                            END
    RETURN 
END


--With
WITH CustomersDEATILS AS (
    SELECT  [Customer ID] = C.ID,
            [Customer Name] = C.[Name- First] + ' ' + C.[Name- Last],
            [Last Order]= CAST(Max(O.[Order DT]) AS date),
            [Time From Last Order (Month)]= (DATEDIFF(MONTH, Max(O.[Order DT]), GETDATE()))
    FROM    CUSTOMERS AS C 
    JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID]
    JOIN ORDERS AS O ON CC.[Card Number] = O.[Card Number]
    GROUP BY C.ID, C.[Name- First], C.[Name- Last]
),
IsAccountUser AS (
	SELECT CustomersDEATILS.[Customer ID] ,[Account User] = Case when [Join Date] IS NOT NULL THEN 'Yes' ELSE 'No' END
	FROM CustomersDEATILS LEFT JOIN  [ACCOUNTS USERS] AS AU ON CustomersDEATILS.[Customer ID] = AU.ID
	GROUP BY CustomersDEATILS.[Customer ID], AU.[Join Date]
),
OrdersDEATILS AS (
    SELECT [Order ID] = O.[Order ID],
           [Total Payment] = ROUND(SUM(P.Price * CON.Quantity * (1 - CON.Discount) * (1 - O.Coupon)), 2),
           C.ID
    FROM CUSTOMERS AS C 
    JOIN [CREDIT CARDS] AS CC ON C.ID = CC.[Customer ID]
    JOIN ORDERS AS O ON CC.[Card Number] = O.[Card Number]
    JOIN [CONTAINS] AS CON ON O.[Order ID] = CON.[Order ID]
    JOIN PRODUCTS AS P ON CON.[Serial Number] = P.[Serial Number]
    GROUP BY O.[Order ID], C.ID
),
DEATILS AS (
    SELECT [Total] = SUM(OrdersDEATILS.[Total Payment]),
           [Avg Payment] = ROUND(SUM(OrdersDEATILS.[Total Payment]) / COUNT(OrdersDEATILS.[Order ID]), 2),
           [Number Of Orders] = COUNT(OrdersDEATILS.[Order ID]),
           OrdersDEATILS.ID
    FROM OrdersDEATILS
    GROUP BY OrdersDEATILS.ID
)
SELECT  CustomersDEATILS.[Customer ID],
        CustomersDEATILS.[Customer Name],
        CustomersDEATILS.[Last Order],
        CustomersDEATILS.[Time From Last Order (Month)],
		IsAccountUser.[Account User],
        [Total Payment Of Orders] = ROUND(DEATILS.Total, 2),
        [Average Payment] = DEATILS.[Avg Payment],
        L.[Loyalty Club],
        [Club Benefit] = ROUND(L.[Club benefit], 2)
FROM    CustomersDEATILS
JOIN DEATILS ON CustomersDEATILS.[Customer ID] = DEATILS.ID 
JOIN IsAccountUser ON CustomersDEATILS.[Customer ID] = IsAccountUser.[Customer ID]
CROSS APPLY [bgu-users\zilbemay].loyaltyLevelPlusPoints(DEATILS.[Total]) AS L


